# ============================================================
# webhook_server.py — Flask server receiving MegaPay callbacks
# Callback format confirmed from: https://megapay.co.ke/documentation
# ResponseCode 0 = success | TransactionReceipt = M-Pesa ref
# TransactionReference = telegram_id (set by us at STK initiation)
# ============================================================

import asyncio
import logging
from datetime import datetime, timedelta
from flask import Flask, request, jsonify
from telegram import Update

import database
from config import ADMIN_ID, PLANS, PAYMENT_SUCCESS_MESSAGE, ADMIN_PAYMENT_NOTIFICATION

logger = logging.getLogger(__name__)

_bot_loop    = None
_bot         = None
_application = None


def set_bot(bot, loop, application=None):
    global _bot, _bot_loop, _application
    _bot         = bot
    _bot_loop    = loop
    _application = application


def create_webhook_app() -> Flask:
    app = Flask(__name__)

    @app.route("/webhook/megapay", methods=["POST"])
    def mpesa_callback():
        try:
            data = request.get_json(force=True, silent=True) or {}
            logger.info("MegaPay callback: %s", data)

            response_code = data.get("ResponseCode")
            mpesa_ref     = data.get("TransactionReceipt", "")
            telegram_ref  = str(data.get("TransactionReference", ""))
            phone         = str(data.get("Msisdn", ""))
            checkout_id   = data.get("CheckoutRequestID", "")

            # Non-zero ResponseCode = failed/cancelled
            if str(response_code) != "0" and response_code != 0:
                desc = data.get("ResponseDescription", "Payment cancelled or failed.")
                logger.info("Non-success callback: ResponseCode=%s", response_code)

                pending = None
                if telegram_ref.isdigit():
                    pending = database.get_pending_by_telegram_id(int(telegram_ref))
                if not pending and checkout_id:
                    pending = database.get_pending(checkout_id)

                if pending and _bot and _bot_loop:
                    asyncio.run_coroutine_threadsafe(
                        _notify_failed(pending["telegram_id"], desc),
                        _bot_loop,
                    )
                return jsonify({"status": "ok"}), 200

            # ── Locate the pending payment record ──────────────
            pending = None
            if telegram_ref.isdigit():
                pending = database.get_pending_by_telegram_id(int(telegram_ref))
            if not pending and checkout_id:
                pending = database.get_pending(checkout_id)
            if not pending and phone:
                pending = database.get_pending_by_phone("254" + phone[-9:])

            if not pending:
                logger.warning(
                    "No pending payment found: ref=%s, checkout=%s, phone=%s",
                    telegram_ref, checkout_id, phone,
                )
                return jsonify({"status": "ok"}), 200

            # FIX: Delete pending BEFORE processing to avoid duplicate callbacks
            # Use the correct identifier that exists in the pending row
            pending_checkout_id = pending.get("checkout_request_id", "")
            if pending_checkout_id:
                database.delete_pending(pending_checkout_id)
            elif telegram_ref.isdigit():
                # Fallback: delete by telegram_id directly
                database.delete_pending_by_telegram_id(int(telegram_ref))

            if _bot and _bot_loop:
                asyncio.run_coroutine_threadsafe(
                    _process_payment(pending, mpesa_ref, phone or pending.get("phone", "")),
                    _bot_loop,
                )

        except Exception as exc:
            logger.error("Webhook error: %s", exc, exc_info=True)

        return jsonify({"status": "ok"}), 200

    @app.route("/webhook/telegram", methods=["POST"])
    def telegram_webhook():
        """Receive updates from Telegram and feed them into the bot application."""
        if _application is None or _bot_loop is None:
            logger.warning("Telegram webhook received but application not ready yet.")
            return jsonify({"status": "not ready"}), 503

        try:
            data = request.get_json(force=True, silent=True) or {}
            logger.debug("Telegram raw update payload: %s", data)

            update = Update.de_json(data, _bot)

            update_id = getattr(update, "update_id", "?")
            if update.callback_query:
                cb = update.callback_query
                logger.info(
                    "Telegram update #%s | type=callback_query | user=%s | data=%r",
                    update_id,
                    cb.from_user.id if cb.from_user else "?",
                    cb.data,
                )
            elif update.message:
                msg = update.message
                logger.info(
                    "Telegram update #%s | type=message | user=%s | text=%r",
                    update_id,
                    msg.from_user.id if msg.from_user else "?",
                    msg.text,
                )
            else:
                logger.info("Telegram update #%s | type=other", update_id)

            future = asyncio.run_coroutine_threadsafe(
                _application.process_update(update),
                _bot_loop,
            )
            try:
                future.result(timeout=30)
                logger.info("Telegram update #%s processed successfully.", update_id)
            except Exception as exc:
                logger.error(
                    "process_update raised for update #%s: %s",
                    update_id, exc, exc_info=True,
                )
        except Exception as exc:
            logger.error("Error processing Telegram update: %s", exc, exc_info=True)

        return jsonify({"status": "ok"}), 200

    @app.route("/health", methods=["GET"])
    def health():
        return jsonify({"status": "running", "bot": "PREMIUM VIP"}), 200

    return app


# ── Async helpers (executed in the bot event loop) ────────────

async def _process_payment(pending: dict, mpesa_ref: str, phone: str):
    from config import CHANNEL_ID
    telegram_id = pending["telegram_id"]
    plan_key    = pending["plan"]
    amount      = pending["amount"]
    phone       = phone or pending["phone"]

    plan_info = PLANS.get(plan_key, {})
    end_date  = datetime.now() + timedelta(days=plan_info.get("days", 30))
    user      = database.get_user(telegram_id) or {}
    name      = user.get("first_name") or "Subscriber"

    try:
        invite = await _bot.create_chat_invite_link(
            chat_id=CHANNEL_ID,
            member_limit=1,
            name="%s_%s" % (name[:20], plan_key),
        )
        invite_link = invite.invite_link
    except Exception as exc:
        logger.error("Could not create invite link for %s: %s", telegram_id, exc)
        invite_link = "Contact @PREMIUMVVIPADMIN for your link"

    database.add_subscription(telegram_id, plan_key, amount, end_date, invite_link, mpesa_ref)
    database.add_payment(telegram_id, phone, amount, plan_key, mpesa_ref)

    user_msg = PAYMENT_SUCCESS_MESSAGE.format(
        amount=amount,
        emoji=plan_info.get("emoji", ""),
        plan=plan_info.get("label", plan_key),
        mpesa_ref=mpesa_ref,
        end_date=end_date.strftime("%d %b %Y at %H:%M"),
        invite_link=invite_link,
    )
    try:
        await _bot.send_message(chat_id=telegram_id, text=user_msg, parse_mode="Markdown")
        logger.info("Payment success message sent to user %s", telegram_id)
    except Exception as exc:
        logger.error("Failed to notify user %s: %s", telegram_id, exc)

    # ── Admin notification ─────────────────────────────────────
    admin_msg = ADMIN_PAYMENT_NOTIFICATION.format(
        name=name,
        telegram_id=telegram_id,
        phone=phone,
        amount=amount,
        plan="%s %s" % (plan_info.get("emoji", ""), plan_info.get("label", plan_key)),
        mpesa_ref=mpesa_ref,
        end_date=end_date.strftime("%d %b %Y"),
    )
    try:
        await _bot.send_message(chat_id=ADMIN_ID, text=admin_msg, parse_mode="Markdown")
        logger.info("Admin payment notification sent for user %s", telegram_id)
    except Exception as exc:
        logger.error("Failed to notify admin (ADMIN_ID=%s): %s", ADMIN_ID, exc)


async def _notify_failed(telegram_id: int, reason: str):
    msg = (
        "❌ *Payment Not Completed*\n\n"
        "Reason: %s\n\n"
        "Tap /start to try again or contact @PREMIUMVVIPADMIN." % reason
    )
    try:
        await _bot.send_message(chat_id=telegram_id, text=msg, parse_mode="Markdown")
    except Exception as exc:
        logger.error("Could not notify %s of failure: %s", telegram_id, exc)
