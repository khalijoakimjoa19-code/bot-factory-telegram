# ============================================================
# config.py — All bot settings. Edit values here as needed.
# ============================================================

import os

# ── Telegram ─────────────────────────────────────────────────
BOT_TOKEN    = os.getenv("BOT_TOKEN",    "8732360020:AAFJv4G4V5op74SgwoFMbI21sdlIaTIZTgE")
CHANNEL_ID   = int(os.getenv("CHANNEL_ID",  "-1003701835008"))
ADMIN_ID     = int(os.getenv("ADMIN_ID",    "8584329987"))
ADMIN_USERNAME = "@PREMIUMVVIPADMIN"
SUPPORT_USERNAME = "@PREMIUMVVIPADMIN"

# ── MegaPay ──────────────────────────────────────────────────
MEGAPAY_API_KEY      = os.getenv("MEGAPAY_API_KEY", "MGPY0kKzOR75")
MEGAPAY_CALLBACK_URL = "https://mpesa-vvip.find-hotbabes.com/webhook/megapay"
# ⚠️ REQUIRED: Replace with your MegaPay login email
MEGAPAY_EMAIL        = os.getenv("MEGAPAY_EMAIL", "soilamaizi555@gmail.com")

# ── Server ────────────────────────────────────────────────────
WEBHOOK_PORT = int(os.getenv("PORT", "5000"))
DB_PATH      = "premium_bot.db"

# Explicit WEBHOOK_URL takes priority; falls back to constructing one from
# RAILWAY_PUBLIC_DOMAIN (automatically injected by Railway on every service).
_railway_domain = os.getenv("RAILWAY_PUBLIC_DOMAIN", "")
_webhook_url = os.getenv(
    "WEBHOOK_URL",
    f"https://{_railway_domain}/webhook/telegram" if _railway_domain else None,
)
# Ensure the path is always present — guard against WEBHOOK_URL being set to
# just the bare domain (e.g. "https://example.up.railway.app") without the path.
if _webhook_url and not _webhook_url.rstrip("/").endswith("/webhook/telegram"):
    _webhook_url = _webhook_url.rstrip("/") + "/webhook/telegram"
WEBHOOK_URL = _webhook_url


# ── Subscription Plans ────────────────────────────────────────
PLANS = {
    "daily":     {"label": "Daily",    "price": 250,  "days": 1,   "emoji": "⚡"},
    "weekly":    {"label": "Weekly",   "price": 100,  "days": 7,   "emoji": "📅"},
    "monthly":   {"label": "Monthly",  "price": 350,  "days": 30,  "emoji": "🗓️"},
    "quarterly": {"label": "3 Months", "price": 1000, "days": 90,  "emoji": "💎"},
    "yearly":    {"label": "Yearly",   "price": 3500, "days": 365, "emoji": "👑"},
}

# ── Reminder Settings ─────────────────────────────────────────
REMINDER_DAYS_BEFORE = 2   # Send expiry warning this many days before end

# ── Messages ──────────────────────────────────────────────────

WELCOME_MESSAGE = (
    "Welcome, {name}! 👋\n\n"
    "🔞 *Premium Channel Subscription Assistant Bot (18+)*\n\n"
    "Choose a package, pay via M-Pesa, and you'll receive a "
    "private one-time invite link to the VIP Room.\n\n"
    "Need help? Tap 💬 Support or message @PREMIUMVVIPADMIN."
)

RESUBSCRIBE_MESSAGE = (
    "🔔 Hey {name},\n\n"
    "We noticed you haven't been in the VIP Room lately 👀\n\n"
    "We miss having you around — the exclusive celebrity gossip, "
    "the leaked videos, the hook ups… it's just not the same without you.\n\n"
    "While you've been away… we've been having way too much fun "
    "in the VIP Room. 😉\n\n"
    "Come back today and we'll make sure you're caught up on "
    "everything you missed.\n\n"
    "Choose a package below to re-subscribe 🙏"
)

EXPIRY_REMINDER_MESSAGE = (
    "⏰ Hey {name}!\n\n"
    "Your *{plan}* subscription expires in *{days} day(s)* "
    "(on {date}).\n\n"
    "Don't get locked out of the VIP Room! Renew now to keep "
    "enjoying exclusive content 🔥\n\n"
    "Tap /start to choose a renewal package."
)

PAYMENT_PENDING_MESSAGE = (
    "📲 *STK Push Sent!*\n\n"
    "Check your phone — enter your M-Pesa PIN to pay *KES {amount}*.\n\n"
    "⏳ Waiting for confirmation… (up to 2 minutes)\n"
    "Once paid, your invite link will appear here automatically."
)

PAYMENT_SUCCESS_MESSAGE = (
    "✅ *Payment Confirmed!*\n\n"
    "💰 Amount: KES {amount:,}\n"
    "📋 Plan: {emoji} {plan}\n"
    "📱 M-Pesa Ref: `{mpesa_ref}`\n"
    "📅 Expires: {end_date}\n\n"
    "🔗 *Your Private One-Time Invite Link:*\n"
    "{invite_link}\n\n"
    "⚠️ This link is *one-time use only*. Do not share it.\n"
    "Welcome to the VIP Room! 🎉"
)

ADMIN_PAYMENT_NOTIFICATION = (
    "💰 *New Payment Received!*\n\n"
    "👤 User: {name} (`{telegram_id}`)\n"
    "📱 Phone: `{phone}`\n"
    "💳 Amount: KES {amount:,}\n"
    "📋 Plan: {plan}\n"
    "🧾 M-Pesa Ref: `{mpesa_ref}`\n"
    "📅 Expires: {end_date}"
)
