# ============================================================
# scheduler.py — Periodic tasks: reminders + subscription expiry
# ============================================================

import asyncio
import logging
from datetime import datetime, timedelta
from apscheduler.schedulers.asyncio import AsyncIOScheduler

# FIX: Import InlineKeyboardButton at module level, not inside functions
from telegram import InlineKeyboardButton, InlineKeyboardMarkup

import database
from config import (
    CHANNEL_ID, ADMIN_ID, REMINDER_DAYS_BEFORE,
    EXPIRY_REMINDER_MESSAGE, RESUBSCRIBE_MESSAGE, PLANS,
)

logger = logging.getLogger(__name__)


def setup_scheduler(application) -> AsyncIOScheduler:
    scheduler = AsyncIOScheduler(timezone="Africa/Nairobi")

    scheduler.add_job(
        _check_expiring,
        "interval",
        hours=6,
        args=[application],
        id="expiry_reminder",
        next_run_time=datetime.now() + timedelta(minutes=1),
    )

    scheduler.add_job(
        _remove_expired,
        "interval",
        hours=1,
        args=[application],
        id="remove_expired",
        next_run_time=datetime.now() + timedelta(minutes=2),
    )

    scheduler.add_job(
        _cleanup_pending,
        "interval",
        minutes=30,
        id="cleanup_pending",
    )

    scheduler.start()
    logger.info("Scheduler started (Africa/Nairobi timezone).")
    return scheduler


# ── Task: remind users before expiry ──────────────────────────

async def _check_expiring(application):
    bot = application.bot
    expiring = database.get_expiring_soon()
    logger.info(f"Expiry check: {len(expiring)} subscription(s) expiring soon.")

    for sub in expiring:
        telegram_id = sub["telegram_id"]
        name        = sub["first_name"] or "Subscriber"
        plan_key    = sub["plan"]
        end_dt      = datetime.fromisoformat(str(sub["end_date"]))
        days_left   = (end_dt - datetime.now()).days + 1
        plan_label  = PLANS.get(plan_key, {}).get("label", plan_key)

        msg = EXPIRY_REMINDER_MESSAGE.format(
            name=name,
            plan=plan_label,
            days=days_left,
            date=end_dt.strftime("%d %b %Y"),
        )
        try:
            await bot.send_message(
                chat_id=telegram_id,
                text=msg,
                parse_mode="Markdown",
            )
            database.mark_reminded(sub["id"])
            logger.info(f"Sent expiry reminder to {telegram_id} ({name})")
        except Exception as e:
            logger.error(f"Could not remind {telegram_id}: {e}")


# ── Task: remove expired subscribers ──────────────────────────

async def _remove_expired(application):
    bot = application.bot
    expired = database.get_expired()
    logger.info(f"Expired check: {len(expired)} subscription(s) to remove.")

    for sub in expired:
        telegram_id = sub["telegram_id"]
        name        = sub["first_name"] or "Subscriber"
        sub_id      = sub["id"]

        database.deactivate_subscription(sub_id)

        try:
            await bot.ban_chat_member(chat_id=CHANNEL_ID, user_id=telegram_id)
            await bot.unban_chat_member(chat_id=CHANNEL_ID, user_id=telegram_id)
            logger.info(f"Removed {telegram_id} ({name}) from channel.")
        except Exception as e:
            logger.warning(f"Could not remove {telegram_id} from channel: {e}")

        try:
            # FIX: InlineKeyboardButton now imported at top of file — no NameError
            keyboard = _plan_keyboard()
            msg = RESUBSCRIBE_MESSAGE.format(name=name)
            await bot.send_message(
                chat_id=telegram_id,
                text=msg,
                parse_mode="Markdown",
                reply_markup=InlineKeyboardMarkup(keyboard),
            )
        except Exception as e:
            logger.error(f"Could not send re-subscribe message to {telegram_id}: {e}")


# ── Task: cleanup stale pending payments ──────────────────────

async def _cleanup_pending():
    database.cleanup_old_pending(minutes=15)
    logger.debug("Cleaned up old pending payments.")


# ── Helpers ───────────────────────────────────────────────────

def _plan_keyboard():
    """Return inline keyboard rows for all subscription plans."""
    rows = []
    for key, plan in PLANS.items():
        rows.append([
            InlineKeyboardButton(
                f"{plan['emoji']} {plan['label']} — KES {plan['price']:,}",
                callback_data=f"plan_{key}",
            )
        ])
    return rows


# ── Manual trigger (called by admin from bot) ─────────────────

async def manual_remind_all(application):
    """Admin-triggered: send re-subscribe message to ALL expired/inactive subscribers."""
    # FIX: accept application object (not raw bot), access bot via application.bot
    bot = application.bot
    all_users = database.get_all_users()
    sent = 0
    for user in all_users:
        telegram_id = user["telegram_id"]
        active = database.get_active_subscription(telegram_id)
        if active:
            continue   # skip active subscribers
        name = user["first_name"] or "Subscriber"
        try:
            msg = RESUBSCRIBE_MESSAGE.format(name=name)
            await bot.send_message(
                chat_id=telegram_id,
                text=msg,
                parse_mode="Markdown",
                reply_markup=InlineKeyboardMarkup(_plan_keyboard()),
            )
            sent += 1
        except Exception:
            pass
    return sent
