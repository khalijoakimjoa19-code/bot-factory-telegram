# ============================================================
# database.py — All SQLite database operations
# ============================================================

import sqlite3
import logging
from datetime import datetime, timedelta
from config import DB_PATH, REMINDER_DAYS_BEFORE

logger = logging.getLogger(__name__)


def _conn():
    """Return a thread-safe SQLite connection."""
    con = sqlite3.connect(DB_PATH, check_same_thread=False)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA journal_mode=WAL")   # better concurrent access
    return con


# ── Initialisation ────────────────────────────────────────────

def init_db():
    """Create all tables if they don't exist."""
    con = _conn()
    c = con.cursor()

    c.execute("""
        CREATE TABLE IF NOT EXISTS users (
            telegram_id  INTEGER PRIMARY KEY,
            first_name   TEXT,
            username     TEXT,
            phone        TEXT,
            joined_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)

    c.execute("""
        CREATE TABLE IF NOT EXISTS subscriptions (
            id           INTEGER PRIMARY KEY AUTOINCREMENT,
            telegram_id  INTEGER NOT NULL,
            plan         TEXT    NOT NULL,
            amount       INTEGER NOT NULL,
            start_date   TIMESTAMP,
            end_date     TIMESTAMP,
            active       INTEGER DEFAULT 1,
            reminded     INTEGER DEFAULT 0,
            invite_link  TEXT,
            payment_ref  TEXT,
            FOREIGN KEY (telegram_id) REFERENCES users(telegram_id)
        )
    """)

    c.execute("""
        CREATE TABLE IF NOT EXISTS payments (
            id           INTEGER PRIMARY KEY AUTOINCREMENT,
            telegram_id  INTEGER,
            phone        TEXT,
            amount       INTEGER,
            plan         TEXT,
            mpesa_ref    TEXT,
            status       TEXT DEFAULT 'success',
            created_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (telegram_id) REFERENCES users(telegram_id)
        )
    """)

    # Temporary holding table: one row per pending STK push
    c.execute("""
        CREATE TABLE IF NOT EXISTS pending_payments (
            id                   INTEGER PRIMARY KEY AUTOINCREMENT,
            telegram_id          INTEGER,
            phone                TEXT,
            amount               INTEGER,
            plan                 TEXT,
            checkout_request_id  TEXT UNIQUE,
            created_at           TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)

    con.commit()
    con.close()
    logger.info("Database initialised.")


# ── Users ─────────────────────────────────────────────────────

def upsert_user(telegram_id: int, first_name: str, username: str):
    con = _conn()
    con.execute(
        "INSERT OR REPLACE INTO users (telegram_id, first_name, username) VALUES (?,?,?)",
        (telegram_id, first_name or "User", username or ""),
    )
    con.commit(); con.close()


def update_user_phone(telegram_id: int, phone: str):
    con = _conn()
    con.execute("UPDATE users SET phone=? WHERE telegram_id=?", (phone, telegram_id))
    con.commit(); con.close()


def get_user(telegram_id: int):
    con = _conn()
    row = con.execute("SELECT * FROM users WHERE telegram_id=?", (telegram_id,)).fetchone()
    con.close()
    return dict(row) if row else None


def get_all_users():
    con = _conn()
    rows = con.execute("SELECT * FROM users").fetchall()
    con.close()
    return [dict(r) for r in rows]


def get_all_active_subscribers():
    con = _conn()
    rows = con.execute("""
        SELECT DISTINCT u.telegram_id, u.first_name, u.username
        FROM users u
        JOIN subscriptions s ON u.telegram_id = s.telegram_id
        WHERE s.active = 1
    """).fetchall()
    con.close()
    return [dict(r) for r in rows]


# ── Pending Payments ──────────────────────────────────────────

def add_pending(telegram_id: int, phone: str, amount: int,
                plan: str, checkout_request_id: str):
    con = _conn()
    con.execute(
        """INSERT OR REPLACE INTO pending_payments
           (telegram_id, phone, amount, plan, checkout_request_id)
           VALUES (?,?,?,?,?)""",
        (telegram_id, phone, amount, plan, checkout_request_id),
    )
    con.commit(); con.close()


def get_pending(checkout_request_id: str):
    con = _conn()
    row = con.execute(
        "SELECT * FROM pending_payments WHERE checkout_request_id=?",
        (checkout_request_id,),
    ).fetchone()
    con.close()
    return dict(row) if row else None


def get_pending_by_telegram_id(telegram_id: int):
    """Primary match method: look up pending payment by telegram_id (stored as reference)."""
    con = _conn()
    row = con.execute(
        "SELECT * FROM pending_payments WHERE telegram_id=? ORDER BY created_at DESC LIMIT 1",
        (telegram_id,),
    ).fetchone()
    con.close()
    return dict(row) if row else None


def get_pending_by_phone(phone: str):
    """Fallback: look up pending payment by phone number (last entry)."""
    con = _conn()
    row = con.execute(
        "SELECT * FROM pending_payments WHERE phone=? ORDER BY created_at DESC LIMIT 1",
        (phone,),
    ).fetchone()
    con.close()
    return dict(row) if row else None


def delete_pending(checkout_request_id: str):
    con = _conn()
    con.execute("DELETE FROM pending_payments WHERE checkout_request_id=?",
                (checkout_request_id,))
    con.commit(); con.close()


def delete_pending_by_telegram_id(telegram_id: int):
    """Fallback: delete pending payment by telegram_id when checkout_request_id is unavailable."""
    con = _conn()
    con.execute(
        "DELETE FROM pending_payments WHERE telegram_id=?",
        (telegram_id,),
    )
    con.commit(); con.close()


def cleanup_old_pending(minutes: int = 15):
    """Remove stale pending rows older than `minutes`."""
    con = _conn()
    cutoff = datetime.now() - timedelta(minutes=minutes)
    con.execute("DELETE FROM pending_payments WHERE created_at < ?", (cutoff,))
    con.commit(); con.close()


# ── Payments (confirmed) ──────────────────────────────────────

def add_payment(telegram_id: int, phone: str, amount: int,
                plan: str, mpesa_ref: str):
    con = _conn()
    con.execute(
        """INSERT INTO payments (telegram_id, phone, amount, plan, mpesa_ref, status)
           VALUES (?,?,?,?,?,'success')""",
        (telegram_id, phone, amount, plan, mpesa_ref),
    )
    # Also store phone on user record if not set
    con.execute(
        "UPDATE users SET phone=? WHERE telegram_id=? AND (phone IS NULL OR phone='')",
        (phone, telegram_id),
    )
    con.commit(); con.close()


# ── Subscriptions ─────────────────────────────────────────────

def add_subscription(telegram_id: int, plan: str, amount: int,
                     end_date: datetime, invite_link: str, payment_ref: str):
    con = _conn()
    # Deactivate any previous active subscription
    con.execute(
        "UPDATE subscriptions SET active=0 WHERE telegram_id=? AND active=1",
        (telegram_id,),
    )
    con.execute(
        """INSERT INTO subscriptions
           (telegram_id, plan, amount, start_date, end_date, active, invite_link, payment_ref)
           VALUES (?,?,?,?,?,1,?,?)""",
        (telegram_id, plan, amount, datetime.now(), end_date, invite_link, payment_ref),
    )
    con.commit(); con.close()


def get_active_subscription(telegram_id: int):
    con = _conn()
    row = con.execute(
        "SELECT * FROM subscriptions WHERE telegram_id=? AND active=1",
        (telegram_id,),
    ).fetchone()
    con.close()
    return dict(row) if row else None


def get_expiring_soon():
    """Return active subs expiring in exactly REMINDER_DAYS_BEFORE days (not yet reminded)."""
    target_day_start = (datetime.now() + timedelta(days=REMINDER_DAYS_BEFORE)).replace(
        hour=0, minute=0, second=0, microsecond=0
    )
    target_day_end = target_day_start.replace(hour=23, minute=59, second=59)
    con = _conn()
    rows = con.execute(
        """SELECT s.*, u.first_name, u.username
           FROM subscriptions s
           JOIN users u ON s.telegram_id = u.telegram_id
           WHERE s.active=1 AND s.reminded=0
             AND s.end_date BETWEEN ? AND ?""",
        (target_day_start, target_day_end),
    ).fetchall()
    con.close()
    return [dict(r) for r in rows]


def get_expired():
    """Return all active subs whose end_date has passed."""
    con = _conn()
    rows = con.execute(
        """SELECT s.*, u.first_name, u.username
           FROM subscriptions s
           JOIN users u ON s.telegram_id = u.telegram_id
           WHERE s.active=1 AND s.end_date <= ?""",
        (datetime.now(),),
    ).fetchall()
    con.close()
    return [dict(r) for r in rows]


def deactivate_subscription(sub_id: int):
    con = _conn()
    con.execute("UPDATE subscriptions SET active=0 WHERE id=?", (sub_id,))
    con.commit(); con.close()


def mark_reminded(sub_id: int):
    con = _conn()
    con.execute("UPDATE subscriptions SET reminded=1 WHERE id=?", (sub_id,))
    con.commit(); con.close()


# ── Analytics ─────────────────────────────────────────────────

def get_analytics():
    con = _conn()

    total_users    = con.execute("SELECT COUNT(*) FROM users").fetchone()[0]
    active_subs    = con.execute("SELECT COUNT(*) FROM subscriptions WHERE active=1").fetchone()[0]
    expired_subs   = con.execute("SELECT COUNT(*) FROM subscriptions WHERE active=0").fetchone()[0]
    total_revenue  = con.execute(
        "SELECT COALESCE(SUM(amount),0) FROM payments WHERE status='success'"
    ).fetchone()[0]
    total_payments = con.execute(
        "SELECT COUNT(*) FROM payments WHERE status='success'"
    ).fetchone()[0]

    plan_rows = con.execute(
        "SELECT plan, COUNT(*) as cnt FROM subscriptions WHERE active=1 GROUP BY plan"
    ).fetchall()
    plan_breakdown = {r["plan"]: r["cnt"] for r in plan_rows}

    # Revenue this month
    month_start = datetime.now().replace(day=1, hour=0, minute=0, second=0)
    monthly_revenue = con.execute(
        "SELECT COALESCE(SUM(amount),0) FROM payments WHERE status='success' AND created_at >= ?",
        (month_start,),
    ).fetchone()[0]

    # Recent 5 payments
    recent = con.execute(
        """SELECT p.*, u.first_name FROM payments p
           JOIN users u ON p.telegram_id = u.telegram_id
           WHERE p.status='success'
           ORDER BY p.created_at DESC LIMIT 5"""
    ).fetchall()
    recent_payments = [dict(r) for r in recent]

    con.close()
    return {
        "total_users":      total_users,
        "active_subs":      active_subs,
        "expired_subs":     expired_subs,
        "total_revenue":    total_revenue,
        "monthly_revenue":  monthly_revenue,
        "total_payments":   total_payments,
        "plan_breakdown":   plan_breakdown,
        "recent_payments":  recent_payments,
    }
