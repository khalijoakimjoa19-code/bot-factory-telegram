# ============================================================
# mpesa.py — MegaPay STK Push initiation
# Endpoint and payload confirmed from: https://megapay.co.ke/documentation
# ============================================================

import logging
import aiohttp
from config import MEGAPAY_API_KEY, MEGAPAY_EMAIL

logger = logging.getLogger(__name__)

# ✅ Confirmed endpoint from MegaPay docs
MEGAPAY_STK_URL = "https://megapay.co.ke/backend/v1/initiatestk"


def format_phone(phone: str) -> str:
    """
    Normalise a Kenyan phone number to 254XXXXXXXXX format.
    Accepts: 07XX, 01XX, 254XX, +254XX
    """
    phone = phone.strip().replace(" ", "").replace("-", "")
    if phone.startswith("+"):
        phone = phone[1:]
    if phone.startswith("0"):
        phone = "254" + phone[1:]
    if not phone.startswith("254"):
        phone = "254" + phone
    return phone


def is_valid_phone(phone: str) -> bool:
    """Basic validation for a Kenyan phone number after formatting."""
    formatted = format_phone(phone)
    return (
        formatted.startswith("254")
        and len(formatted) == 12
        and formatted[3:].isdigit()
    )


async def initiate_stk_push(phone: str, amount: int, plan_label: str,
                             telegram_id: int = 0) -> dict:
    """
    Send an STK push request to MegaPay.

    Uses telegram_id as the `reference` field so we can match the
    webhook callback back to the correct user without needing CheckoutRequestID.

    Returns a dict with:
        success (bool)
        transaction_request_id (str) — MegaPay's internal ID
        message (str)                — human-readable status
    """
    formatted_phone = format_phone(phone)

    # ✅ Exact payload format from MegaPay docs
    payload = {
        "api_key":   MEGAPAY_API_KEY,
        "email":     MEGAPAY_EMAIL,          # Your MegaPay login email
        "amount":    str(amount),
        "msisdn":    formatted_phone,
        "reference": str(telegram_id),       # We use telegram_id to match the callback
    }

    headers = {"Content-Type": "application/json"}

    logger.info(
        f"Initiating STK push → phone={formatted_phone}, "
        f"amount={amount}, plan={plan_label}, ref={telegram_id}"
    )

    try:
        async with aiohttp.ClientSession() as session:
            async with session.post(
                MEGAPAY_STK_URL,
                json=payload,
                headers=headers,
                timeout=aiohttp.ClientTimeout(total=30),
            ) as resp:
                data = await resp.json(content_type=None)
                logger.info(f"MegaPay STK response ({resp.status}): {data}")

                # ✅ MegaPay success response: {"success": "200", "transaction_request_id": "..."}
                success = str(data.get("success", "")) == "200"
                transaction_id = data.get("transaction_request_id", "")
                message = data.get("massage") or data.get("message") or (
                    "STK push sent successfully" if success else "STK push failed"
                )

                return {
                    "success":                success,
                    "transaction_request_id": transaction_id,
                    "message":                message,
                    "raw":                    data,
                }

    except aiohttp.ClientConnectorError as e:
        logger.error(f"MegaPay connection error: {e}")
        return {
            "success": False,
            "transaction_request_id": "",
            "message": "Could not reach payment server. Please try again.",
        }
    except Exception as e:
        logger.error(f"MegaPay unexpected error: {e}")
        return {
            "success": False,
            "transaction_request_id": "",
            "message": f"Payment error: {e}",
        }
