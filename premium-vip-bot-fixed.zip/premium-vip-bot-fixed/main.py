# ============================================================
# main.py — Entry point: starts bot + webhook server + scheduler
# ============================================================

import asyncio
import logging
import threading

from telegram.ext import Application

from config import BOT_TOKEN, WEBHOOK_PORT, WEBHOOK_URL
from database import init_db
from bot import setup_bot
from webhook_server import create_webhook_app, set_bot
from scheduler import setup_scheduler

logging.basicConfig(
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
    level=logging.INFO,
)
logger = logging.getLogger(__name__)


async def run():
    # 1. Initialise database
    init_db()

    # 2. Build Telegram Application
    application = Application.builder().token(BOT_TOKEN).build()

    # 3. Register bot handlers
    setup_bot(application)

    # 4. Setup APScheduler
    setup_scheduler(application)

    # 5. Start Flask webhook server in a background daemon thread
    #    (passes bot + current event loop so Flask can call async methods)
    loop = asyncio.get_event_loop()
    flask_app = create_webhook_app()

    def run_flask():
        flask_app.run(host="0.0.0.0", port=WEBHOOK_PORT, debug=False, use_reloader=False)

    flask_thread = threading.Thread(target=run_flask, daemon=True)
    flask_thread.start()
    logger.info(f"Flask webhook server started on port {WEBHOOK_PORT}")

    # 6. Initialise Application and give webhook_server a reference to bot + loop
    await application.initialize()
    set_bot(application.bot, loop, application)
    logger.info("Bot reference injected into webhook server.")

    # 7. Set webhook instead of polling
    if not WEBHOOK_URL:
        raise RuntimeError(
            "Webhook URL is not configured. Set WEBHOOK_URL or RAILWAY_PUBLIC_DOMAIN."
        )
    await application.bot.set_webhook(WEBHOOK_URL, drop_pending_updates=True)
    logger.info(f"Webhook set to {WEBHOOK_URL}")

    await application.start()
    # Don't start polling — webhook handles incoming updates
    logger.info("Bot is running with webhook...")

    # 8. Keep alive
    try:
        await asyncio.Event().wait()
    except (KeyboardInterrupt, SystemExit):
        logger.info("Shutdown signal received.")
    finally:
        await application.bot.delete_webhook()
        await application.stop()
        await application.shutdown()
        logger.info("Bot shut down cleanly.")


if __name__ == "__main__":
    asyncio.run(run())
